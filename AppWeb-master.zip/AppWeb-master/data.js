/*const data = {}
function imprimir() {
    console.log("Data Prueba");

}
data.imprimir = imprimir
module.exports = data*/