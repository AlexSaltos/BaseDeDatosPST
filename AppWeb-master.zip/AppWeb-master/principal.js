/*const data=require('./data.js');
data.imprimir();*/